function [MI] = Mutualinformation(J,K)
%takes two images of equal size and pixel value ranges and returns the
% mutual information. No error checking
%%an example of input value is 256x256 (pixel values range from 0-255) 
%%dont use im2double to change image pixel intensity
%

%uncomment following block and put comment before function and end keywork
%at the begining and at the end of the fucntioin definition to test the
%function independently

% clc
% clear all
% close all 
% 
% dir_files = './lena/';
% files = dir([dir_files '*.png']);
% m_f=size(files,1);
% J =imread([dir_files files(2).name]);
% K = imread([dir_files files(1).name]);

%image dimention
dimen = size(J,1);

x = numel(J);
t = 1:x;
xx = J(:)+1;
yy = dimen*K(:);

xx = xx + yy;
xx = sort(xx);

yy(1:x-1) = xx(2:x);

zz = yy - xx;
zz(x) = 1;
zz = t(zz ~=0);

yy = xx(zz);

t = numel(zz);

zz(2:t) = zz(2:t)-zz(1:t-1);
xx = zz/x;

%histgram
jhist = zeros(dimen);
jhist(yy) = xx;

% joint entropy
jent = -sum(xx.*log2(xx));

%mutual information calculation between two image J and K
xx = sum(jhist);
yy = sum(jhist,2);
xx(xx>1e-12) = (xx(xx>1e-12)).^-1;
yy(yy>1e-12) = (yy(yy>1e-12)).^-1;

xx = ones(dimen,1)*xx;
yy = yy*ones(1,dimen);

MI = xx.*yy.*jhist;
MI = sum(jhist(:).*log2(MI(:)+(MI(:)<=1e-12)));

end