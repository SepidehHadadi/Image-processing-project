clear all
close all
clc

dir_files = './lena/';
files = dir([dir_files '*.png']);
m_f=size(files,1);
% for i=1:m_f
%     Im=imread([dir_files files(i).name]);
%     subplot(2,2,i),imshow(Im)
% end

ImFix =im2double(imread([dir_files files(4).name]));
%ImMoving = im2double(imread([dir_files files(1).name]));
ImMoving = im2double(imread([dir_files files(3).name]));
% changing sclae step in multi resolution
n_sacle =10;
step =1;
for xd=1:step:n_sacle
    for yd=1:step:n_sacle
        for td=1:step:n_sacle
            scale=[xd yd td];
            [Icor, M]=affineReg2D_scale(ImMoving,ImFix, scale);
             imwrite(Icor,['./scale/' num2str(scale(1)) '_' num2str(scale(2)) '_' num2str(scale(3)) '.jpg'])
             imwrite((ImFix - Icor),['./scale/diff_' num2str(scale(1)) '_' num2str(scale(2)) '_' num2str(scale(3)) '.jpg'])
        end
    end
end
figure
subplot(2,2,1),imshow(ImFix), title('Fixed image')
subplot(2,2,2),imshow(ImMoving), title('moving image')
subplot(2,2,3),imshow(Icor), title('image after registration')
subplot(2,2,4),imshow(abs(ImFix-Icor)), title('image difference')