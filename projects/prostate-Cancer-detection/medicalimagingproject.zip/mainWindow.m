function varargout = mainWindow(varargin)
% MAINWINDOW M-file for mainWindow.fig
%      MAINWINDOW, by itself, creates a new MAINWINDOW or raises the existing
%      singleton*.
%
%      H = MAINWINDOW returns the handle to a new MAINWINDOW or the handle to
%      the existing singleton*.
%
%      MAINWINDOW('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAINWINDOW.M with the given input arguments.
%
%      MAINWINDOW('Property','Value',...) creates a new MAINWINDOW or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before mainWindow_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to mainWindow_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help mainWindow

% Last Modified by GUIDE v2.5 05-Oct-2010 12:50:52

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @mainWindow_OpeningFcn, ...
                   'gui_OutputFcn',  @mainWindow_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before mainWindow is made visible.
function mainWindow_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to mainWindow (see VARARGIN)

% Choose default command line output for mainWindow
handles.output = hObject;
handles.reopen = 0;
handles.bROI = 0;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes mainWindow wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = mainWindow_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --------------------------------------------------------------------
function FileMenu_Callback(hObject, eventdata, handles)
% hObject    handle to FileMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function OpenMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to OpenMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%% Parameters
handles.Rsearch = 5;
handles.Rsim = 2;
handles.h = 1.40;
%addpath('Processing');

handles.bROI = 0;

if (handles.reopen == 1)
    clear handles.data;
    clear handles.dir_name;
    clear handles.current_slice;
    clear handles.current_serie;
    clear handles.nb_series;
    clear handles.nb_slices;
end

handles.reopen = 1;

handles.dir_name = uigetdir('','Open directory ');

if ~isequal(handles.dir_name, 0)
    %%% Create a structure with all information inside the directory
    dir_struct = dir(handles.dir_name);
    %%% Add path to enable the reading of all files
    addpath(handles.dir_name);
    %%% Filter only DICOM images
    [nb_files , blabla] = size(dir_struct);
    
    %%% Loading waiting bar
    bar = waitbar(0,'Loading DICOM images ...');
    
    %%% Initialisation
   handles.data.maxValue = 0;
   handles.data.minValue = 0;
    
    for i = 1:nb_files
        %%% Check the type of files present in the directory
        try
            info = dicominfo(dir_struct(i).name);
            if (handles.data.maxValue < info.LargestImagePixelValue)
                handles.data.maxValue = info.LargestImagePixelValue;
            end
            if (handles.data.minValue > info.SmallestImagePixelValue)
                handles.data.minValue = info.SmallestImagePixelValue;
            end
            handles.data.series(info.AcquisitionNumber).time = str2double(info.SeriesTime);
            handles.data.series(info.AcquisitionNumber).image(info.InstanceNumber).fileName = dir_struct(i).name;
            handles.data.series(info.AcquisitionNumber).image(info.InstanceNumber).height = info.Height;
            handles.data.series(info.AcquisitionNumber).image(info.InstanceNumber).width = info.Width;
            handles.data.series(info.AcquisitionNumber).image(info.InstanceNumber).bitDepth = info.BitDepth;
            handles.data.series(info.AcquisitionNumber).image(info.InstanceNumber).colorType = info.ColorType;
            handles.data.series(info.AcquisitionNumber).image(info.InstanceNumber).maxValue = info.LargestImagePixelValue;
            handles.data.series(info.AcquisitionNumber).image(info.InstanceNumber).minValue = info.SmallestImagePixelValue;
            handles.data.series(info.AcquisitionNumber).image(info.InstanceNumber).data = dicomread(dir_struct(i).name);
        catch
            %%% Part to avoid a break in the program for non dicom files
            disp(['The file n� ', num2str(i), ' was not a DICOM image']);
        end
        waitbar(i / nb_files);
    end
    
    close(bar);
    
    %%% Show the first image
    handles.current_slice = 1;
    handles.current_serie = 1;
    set(handles.winImage,'HandleVisibility','ON');
    imshow(handles.data.series(handles.current_serie).image(handles.current_slice).data,'DisplayRange',[]);
    
    %%% Compute the number of series and slides by series
    [blabla,handles.nb_series] = size(handles.data.series);
    [blabla,handles.nb_slices] = size(handles.data.series(1).image);
    
    %%% Set the range of the sliders
    set(handles.sliderTime, 'Max', 1.0);
    set(handles.sliderSlice, 'Max', 1.0);
    set(handles.sliderTime, 'Min', 0);
    set(handles.sliderSlice, 'Min', 0);
    set(handles.sliderTime, 'SliderStep', [1/(handles.nb_series - 1) 1/(handles.nb_series - 1)]);
    set(handles.sliderSlice, 'SliderStep', [1/(handles.nb_slices - 1) 1/(handles.nb_slices - 1)]);
    
    %%% Put the slider at the first position
    set(handles.sliderSlice,'Value', 0);
    set(handles.sliderTime,'Value',0);
    
    set(handles.labelPositionSlice, 'String', [num2str(handles.current_slice), '/', num2str(handles.nb_slices)]);
    set(handles.labelPositionTime, 'String', [num2str(handles.current_serie), '/', num2str(handles.nb_series)]);
    
    %%% Create a vector which is caracteristic of the sampling time
    handles.data.time = zeros(handles.nb_series,1);
    for i = 2:handles.nb_series
        handles.data.time(i) = handles.data.time(i-1) + (handles.data.series(i).time - handles.data.series(i - 1).time);
    end
    
    %%% Save data in memory
    guidata(hObject,handles);
    
    %%% Initialisation button
    set(handles.removeROI, 'Enable', 'OFF');
    set(handles.roiButton, 'Enable', 'ON');
    set(handles.processingButton, 'Enable', 'ON');
end

% --------------------------------------------------------------------
function saveMenu_Callback(hObject, eventdata, handles)
% hObject    handle to saveMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --------------------------------------------------------------------
function PrintMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to PrintMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
printdlg(handles.figure1)

% --------------------------------------------------------------------
function CloseMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to CloseMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = questdlg(['Close ' get(handles.figure1,'Name') '?'],...
                     ['Close ' get(handles.figure1,'Name') '...'],...
                     'Yes','No','Yes');
if strcmp(selection,'No')
    return;
end

delete(handles.figure1)


% --- Executes on slider movement.
function sliderSlice_Callback(hObject, eventdata, handles)
% hObject    handle to sliderSlice (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

%%% Update the image to show
tmp = get(hObject,'Value');
if(handles.bROI == 1)
    handles.region = handles.roi.getPosition;
end
handles.current_slice = uint32(tmp * (handles.nb_slices - 1) + 1);
set(handles.winImage,'HandleVisibility','ON');
imshow(handles.data.series(handles.current_serie).image(handles.current_slice).data,'DisplayRange',[]);
set(handles.labelPositionSlice, 'String', [num2str(handles.current_slice), '/', num2str(handles.nb_slices)]);

%%% Create the roi at the previous position
if(handles.bROI == 1)
    handles.roi = imrect(handles.winImage,handles.region);
end

%%% Save data in memory
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function sliderSlice_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sliderSlice (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function sliderTime_Callback(hObject, eventdata, handles)
% hObject    handle to sliderTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

%%% Update the image to show
tmp = get(hObject,'Value');
if(handles.bROI == 1)
    handles.region = handles.roi.getPosition;
end
handles.current_serie = uint32(tmp * (handles.nb_series - 1) + 1);
set(handles.winImage,'HandleVisibility','ON');
imshow(handles.data.series(handles.current_serie).image(handles.current_slice).data,'DisplayRange',[]);
set(handles.labelPositionTime, 'String', [num2str(handles.current_serie), '/', num2str(handles.nb_series)]);

%%% Create the roi at the previous position
if(handles.bROI == 1)
    handles.roi = imrect(handles.winImage,handles.region);
end

%%% Save data in memory
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function sliderTime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sliderTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in roiButton.
function roiButton_Callback(hObject, eventdata, handles)
% hObject    handle to roiButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%% If a roi is not already placed
if (handles.bROI == 0)
    %%% Enable the ROI selection
    handles.roi = imrect;
    handles.bROI = 1;
    set(handles.removeROI, 'Enable', 'ON');
end

guidata(hObject,handles);


% --- Executes on button press in processingButton.
function processingButton_Callback(hObject, eventdata, handles)
% hObject    handle to processingButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%% Organize the data
%%% Preallocation
handles.data.graph = zeros(handles.data.series(1).image(1).height,handles.data.series(1).image(1).width,handles.nb_series,handles.nb_slices);

for i = 1:handles.nb_slices
    for j = 1:handles.nb_series
        handles.data.graph(:,:,j,i) = handles.data.series(j).image(i).data(:,:);
    end
end

%%% Find the position of the roi if defined otherwise perform for all the
%%% image
if (handles.bROI == 1)
    handles.region = getPosition(handles.roi);
    %%% Allocate for the ROI only
    handles.data.graphROI = zeros(uint16(handles.region(2) + handles.region(4)),uint16(handles.region(1) + handles.region(3)),handles.nb_series,handles.nb_slices);
    %%% Copy the data for the ROI
    row = 1;
    col = 1;
    for i = uint16(handles.region(2)):uint16(handles.region(2) + handles.region(4))
        for j = uint16(handles.region(1)):uint16(handles.region(1) + handles.region(3))
            handles.data.graphROI(row,col,:,:) = handles.data.graph(i,j,:,:);
            row = row + 1;
        end
        col = col + 1;
        row = 1;
    end
else 
    handles.region = [0 0 handles.data.series(handles.current_serie).image(handles.current_slice).width handles.data.series(handles.current_serie).image(handles.current_slice).height];
end

%% ALGORITHM
%%% Beginning of the algorithm

% %%% Denoise the ROI image
% %%% Allocate the denoise image
% handles.data.denoiseROI = zeros(size(handles.data.graphROI));
% %for i = 1:handles.nb_slices
%     for j = 1:handles.nb_series
%     %%% Find the otsu's threshold
%     tic;
%     otsuThres = otsuMethod(handles.data.series(j).image(handles.current_slice).data);
%     handles.data.denoiseROI(:,:,j,handles.current_slice) = UNLmeansfilter2(handles.data.graphROI(:,:,j,handles.current_slice),handles.Rsearch,handles.Rsim,handles.h,sqrt(otsuThres/2));
%     toc;
%     end
% %end
% 
% %%% Extract the size of the data
% [heightData, widthData, handles.nb_series, handles.nb_slices] = size(handles.data.graph);
% 
% figure;
% for i = 1:handles.nb_series
%     subplot(2,1,1);
%     imshow(handles.data.graphROI(:,:,i,handles.current_slice),'DisplayRange',[]);
%     subplot(2,1,2);
%     imshow(handles.data.denoiseROI(:,:,i,handles.current_slice),'DisplayRange',[]);
%     pause;
% end
% 
% figure;
% 
% % for i = uint16(handles.region(2)):uint16(handles.region(2)+handles.region(4))
% %     for j = uint16(handles.region(1)):uint16(handles.region(1)+handles.region(3))
% for i = 1:uint16(handles.region(2)+handles.region(4))
%     for j = 1:uint16(handles.region(1)+handles.region(3))
%         %for k = 1:handles.nb_slices
%             %%% Extract the graph
%             tmpGraph(:,:) = handles.data.denoiseROI(i,j,:,handles.current_slice);
%             tmpGraph2(:,:) = handles.data.graphROI(i,j,:,handles.current_slice);
%             %%% Smooth the graph extracted
%             %%smoothGraph = conv(tmpGraph,gaussfilt,'same');
%             %%% Compute the first derivative
%             %%der1Graph = diff(smoothGraph);
%             %%der1Graph = [der1Graph ; 0];
%             %%% Compute the second derivative
%             %%der2Graph = diff(der1Graph);
%             %%der2Graph = [der2Graph ; 0];
%             hold off;
%             plot(handles.data.time, tmpGraph);
%             hold on;
%             plot(handles.data.time, tmpGraph2,'r');
%             axis([min(handles.data.time), max(handles.data.time), handles.data.minValue, handles.data.maxValue]);
%             pause;
%             %hold on;
%             %plot(handles.data.time, smoothGraph,'y');
%             %plot(handles.data.time, der1Graph,'r');
%             %plot(handles.data.time, der2Graph,'g');
%             %axis auto;
%         %end
%     end
% end

%%% End of the algorithm

guidata(hObject,handles);


% --- Executes on button press in removeROI.
function removeROI_Callback(hObject, eventdata, handles)
% hObject    handle to removeROI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
delete(handles.roi);
set(handles.removeROI, 'Enable', 'OFF');
guidata(hObject,handles);
